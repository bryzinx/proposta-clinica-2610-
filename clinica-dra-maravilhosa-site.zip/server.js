const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const CACHE_MS = 15 * 60 * 1000;
let feedCache = { expiresAt: 0, items: null };

loadLocalEnv();
const PORT = Number(process.env.PORT || 3000);

function loadLocalEnv() {
  const envPath = path.join(ROOT, '.env');
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!match || match[1].startsWith('#') || process.env[match[1]]) continue;
    process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}

function sendJson(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(data));
}

async function getInstagramFeed(res) {
  const { INSTAGRAM_USER_ID: userId, INSTAGRAM_ACCESS_TOKEN: token, INSTAGRAM_API_VERSION: version } = process.env;
  if (!userId || !token || !version) {
    return sendJson(res, 503, { configured: false, items: [] });
  }
  if (feedCache.items && feedCache.expiresAt > Date.now()) {
    return sendJson(res, 200, { configured: true, items: feedCache.items });
  }

  const fields = 'id,caption,media_type,media_url,thumbnail_url,permalink,timestamp';
  const query = new URLSearchParams({ fields, limit: '6', access_token: token });
  const endpoint = `https://graph.instagram.com/${encodeURIComponent(version)}/${encodeURIComponent(userId)}/media?${query}`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);
    const response = await fetch(endpoint, { signal: controller.signal });
    clearTimeout(timeout);
    const body = await response.json();
    if (!response.ok || body.error) {
      console.error('Instagram API request failed:', body.error?.type || response.status);
      return sendJson(res, 502, { configured: true, items: [], error: 'feed_unavailable' });
    }

    const items = (Array.isArray(body.data) ? body.data : [])
      .filter(item => item.permalink && (item.media_url || item.thumbnail_url))
      .slice(0, 6)
      .map(item => ({
        id: item.id,
        caption: typeof item.caption === 'string' ? item.caption.slice(0, 180) : '',
        mediaType: item.media_type || 'IMAGE',
        image: item.media_type === 'VIDEO' ? (item.thumbnail_url || item.media_url) : (item.media_url || item.thumbnail_url),
        permalink: item.permalink,
        timestamp: item.timestamp || ''
      }));

    feedCache = { expiresAt: Date.now() + CACHE_MS, items };
    return sendJson(res, 200, { configured: true, items });
  } catch (error) {
    console.error('Instagram feed could not be reached:', error.name || 'request_error');
    return sendJson(res, 502, { configured: true, items: [], error: 'feed_unavailable' });
  }
}

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon'
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/api/instagram-feed' && req.method === 'GET') {
    return getInstagramFeed(res);
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    return res.end();
  }

  let requested;
  try {
    requested = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  } catch {
    res.writeHead(400);
    return res.end('Bad request');
  }
  const filePath = path.resolve(PUBLIC_DIR, `.${requested}`);
  if (!filePath.startsWith(`${PUBLIC_DIR}${path.sep}`) && filePath !== path.join(PUBLIC_DIR, 'index.html')) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.stat(filePath, (error, stats) => {
    if (error || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Not found');
    }
    const type = contentTypes[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': stats.size,
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, () => {
  console.log(`Clínica Dra. Maravilhosa: http://localhost:${PORT}`);
});
